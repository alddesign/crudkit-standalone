<?php

return [
	//### Admin Login ###
	'username' => 'admin',
	'password' => 'admin',
	
	//### General ###
	'language' => 'de',
	'app_name' => 'CRUDKit',
	'app_name_url'=> 'app', //Your Laravel APP_URL plus this name is the URL to your crudkit. Do not use 'crudkit' or the name of another laravel app.
	'icons' => ['32x32' => 'crudkit/img/crudkit_logo_32.png', '128x128' => 'crudkit/img/crudkit_logo_128.png', '192x192' => 'crudkit/img/crudkit_logo_192.png'], //icon paths. relative to the /public folder. format ['32x32' => 'path/to/image32px.png', '...']
	'skin' => 'blue', //blue,blue-light,yellow,yellow-light,green,green-light,purple,purple-light,red,red-light,black,black-light
	'accent' => 'blue', //blue,yellow,green,purple,red,black
	'theme_selector' => true, //Show the theme selector in menu
	'records_per_page' => 8, //How many record are shown in lists 
	'pagination_limit' => 2, //How many page does the pagination show (in each direction)
	'fontsize' => '16px', //Overall font size. Provide a CSS compatible value (Example: 14px, 2em, 80%,...).
	'show_qrcode' => true,
	'local_timezone' => 'Europe/Vienna', //Used mainly for dates/times in output filenames (xml, csv). This does not change the PHP default timezone - that should be done in laravel (config/app.php)
	
	//### Technical ###
	'records_text_trim_length' => 50,
	'use_custom_error_page' => false, //Displays a fancy Error Page
	'csv_export_with_bom' => true, //Add Byte Order Mark (BOM) to CSV Files
	'export_all_columns' => true, //true = Exports all columns defined for the table, false = exports only summary columns (list)
	'export_enum_label' => true, //true = Exports the Enum label, false = Exports the actual value
	'export_boolean_label' => true, //true = export "yes" or "no", false = export 1 or 0
	'export_lookups' => true,
	'startpage' =>
	[
		'page-id' => 'contact', 
		'type' => 'list',
		'parameters' => []
	],
	'formats_ui' => //Defines how certain datatypes should be displayed
	[
		'datetime' => 'd.m.Y H:i:s',
		'date' => 'd.m.Y',
		'time' => 'H:i:s',
		'decimal_places' => 2,
		'thousands_separator' => '.',
		'decimal_separator' => ','
	],
	'doctrine_dbal_cache' => true, //Enable or disable caching for DB::getDoctrineColumn(); (very time consuming operation). For certain operations Doctrine\DBAL fetches all columns of a DB table, to get extended informations like default-value, not-null...
	'doctrine_dbal_cache_ttl' => 3600 * 24, //Time before the cache has to be refreshed (in seconds),
];
