<?php
require '../vendor/autoload.php';

use Alddesign\Crudkit\Classes\DataProcessor as dp;
use Alddesign\Crudkit\AnilistQueryFactory;

$url = 'https://graphql.anilist.co';

// Here we define our query as a multi-line string
//5081 Bakemonogatari ANIME
//105398 Solo leveling MANGA
//Komi-san 97852
//Komi-san alternative 86813
//main 77, rel 10153, brel 80595

$query = AnilistQueryFactory::getMediaQuery(44893, true);
//$query = AnilistQueryFactory::getTagsQuery();
$data = $query->getRequestData();

//dp::xout($data["json"]["query"]);
// Make the HTTP Api request
$http = new \GuzzleHttp\Client;
$response = $http->post($url, $data);

$body = $response->getBody();

dp::xout(json_decode($body));