<?php $__env->startSection('core-body'); ?>
<?php
	$texts = Alddesign\Crudkit\Classes\DataProcessor::getTexts();
?>
<div class="wrapper">
    <header class="main-header">
        <a href="<?php echo e(url(config('crudkit.app_name_url', 'app'))); ?>" class="logo">
            <?php echo e(config('crudkit.app_name', 'CRUDKit')); ?>

        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>
            <div class="navbar-custom-menu">
            </div>
        </nav>
    </header>
	<!-- Menu -->
	<?php if(!empty($pageMap)): ?>
		<aside class="main-sidebar">
			<section class="sidebar">
				<ul class="sidebar-menu">
					<li class="header"><?php echo e($texts['pages']); ?></li>
					<!-- Pages -->
					<?php $__currentLoopData = $pageMap['pages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuPageId => $menuPageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
						<li role="presentation" <?php if( $menuPageId === $pageId): ?>class="active"<?php endif; ?>>
							<a href="<?php echo e(URL::action('\Alddesign\Crudkit\Controllers\AdminPanelController@listView', ['page-id' => $menuPageId])); ?>"><i class="fa fa-lg fa-book"></i> &nbsp;<?php echo e($menuPageName); ?></a>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<!-- Category Pages -->
					<?php $__currentLoopData = $pageMap['category-pages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $categoryPages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
						<li class="treeview">
							<a href="#"><span><?php echo e($category); ?></span> <i class="fa fa-angle-left pull-right"></i></a>
							<ul class="treeview-menu">
							<?php $__currentLoopData = $categoryPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryPageId => $categoryPageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li role="presentation">
									<a href="<?php echo e(URL::action('\Alddesign\Crudkit\Controllers\AdminPanelController@listView', ['page-id' => $categoryPageId])); ?>"><i class="fa fa-lg fa-book"></i> &nbsp;<?php echo e($categoryPageName); ?></a>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<!-- User -->
					<?php if(session('crudkit-logged-in', false) === true): ?>
						<li class="header">
							<?php if(session('crudkit-admin-user', false)): ?>
								<i class="fa fa-lg fa-user-circle"></i>
							<?php else: ?>
								<i class="fa fa-lg fa-user"></i>
							<?php endif; ?>
							&nbsp;
							<span id=""><?php echo e(session('crudkit-username', '')); ?></span>
						</li>
						<li role="presentation">
							<a href="<?php echo e(URL::action('\Alddesign\Crudkit\Controllers\AdminPanelController@logout')); ?>"> <i class="fa fa-lg fa-sign-out"></i> &nbsp;Logout</a>
						</li>
					<?php endif; ?>
				</ul>
			</section>
		</aside>
	<?php endif; ?>
    <div class="content-wrapper">
        <?php echo $__env->yieldContent('core-admin-panel'); ?>
    </div>
    <footer class="main-footer">
		<div class="pull-right hidden-xs">
			<b><?php echo e($texts['version']); ?></b> <?php echo e(config('crudkit.version')); ?>

		</div>
	  <?php echo $texts['footer_html']; ?>

  </footer>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('crudkit::layouts.core', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>