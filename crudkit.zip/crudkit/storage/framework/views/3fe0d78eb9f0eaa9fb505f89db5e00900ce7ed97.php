<?php
	$texts = Alddesign\Crudkit\Classes\DataProcessor::getTexts();
?>
<?php $__env->startSection('action-buttons'); ?>
	<!-- Chart -->
	<?php if($chartAllowed): ?>
		<a href="<?php echo e($chartPageUrl); ?>" class="btn btn-default crudkit-button" id="curdkit-chart-button"><i class="fa fa-bar-chart"></i> &nbsp;<?php echo e($texts['show_as_chart']); ?></a>
	<?php endif; ?>
	<!-- Export -->
	<?php if($exportAllowed): ?>
		<a href="<?php echo e($exportCsvUrl); ?>" class="btn btn-default crudkit-button" id="curdkit-export-csv-button"><i class="fa fa-file-excel-o"></i> &nbsp;<?php echo e($texts['csv_export']); ?></a>
		<a href="<?php echo e($exportXmlUrl); ?>" class="btn btn-default crudkit-button" id="curdkit-export-xml-button"><i class="fa fa-code"></i> &nbsp;<?php echo e($texts['xml_export']); ?></a>
	<?php endif; ?>
	<!-- Create -->
	<?php if($createAllowed): ?>
		<a href="<?php echo e(url('admin-panel/create-view?page-id='.$pageId)); ?>" class="btn btn-primary crudkit-button" id="curdkit-create-button"><i class="fa fa-plus-circle"></i> &nbsp;<?php echo e($texts['new']); ?></a>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-content'); ?>

	<div class="row crudkit-search crudkit-row">
		<!-- Search From -->
		<form id="search-form" name="search-form" action="<?php echo e(action('\Alddesign\Crudkit\Controllers\AdminPanelController@listView')); ?>" method="GET">
			<input type="hidden" name="page-id" value="<?php echo e($pageId); ?>" />
			<?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<!-- Apply all Filters -->
				<input type="hidden" name="ff-<?php echo e($index); ?>" value="<?php echo e($filter->field); ?>" />
				<input type="hidden" name="fo-<?php echo e($index); ?>" value="<?php echo e($filter->operator); ?>" />
				<input type="hidden" name="fv-<?php echo e($index); ?>" value="<?php echo e($filter->value); ?>" />
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-3">
				<select id="search-column-name" name="search-column-name" class="form-control">
				<?php $__currentLoopData = $summaryColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $summaryColumn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option class="list-group-item" value="<?php echo e($summaryColumn->name); ?>" <?php if($searchColumnName === $summaryColumn->name): ?><?php echo e('selected'); ?><?php endif; ?>><?php echo e($summaryColumn->label); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="col-md-3">
				<div class="input-group">
					<input id="search-text" name="search-text" class="form-control" type="text" value="<?php echo e($searchText); ?>" />
					<span class="input-group-btn">
						<button id="search-button" class="btn btn-default" type="submit"><i class="fa fa-search"></i> &nbsp;<?php echo e($texts['search']); ?></button>
						<?php if($hasSearch): ?>
							<button name="reset-search" value="1" id="reset-search-button" class="btn btn-default" type="submit" ><i class="fa fa-undo"></i> &nbsp;<?php echo e($texts['reset_search']); ?></button>
						<?php endif; ?>
					</span>
				</div>
			</div>
		</form>
	</div>

	<!-- Filter / Search Warining -->
	<?php if($hasFilters || $hasSearch): ?>
		<div class="crudkit-filter-search-warning crudkit-row"> 
			<?php if($hasFilters): ?>
				<div class="alert alert-warning">
					<?php echo $texts['filter_warning_html']; ?>

				</div>	
			<?php endif; ?>
			<?php if($hasSearch): ?>
				<div class="alert alert-warning">
					<?php echo $texts['search_warning_html']; ?>

				</div>	
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<div class="crudkit-record-list crudkit-row">
		<!-- Record List -->
		<table class="table">
			<thead>
			<tr>
			<?php $__currentLoopData = $summaryColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $summaryColumn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if(!$summaryColumn->isHidden('list')): ?>
					<th>
						<?php echo e($summaryColumn->label); ?>

					</th>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actionName => $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($action['on-list']): ?>
					<th>
						<i><?php echo e($action['column-label']); ?></i>
					</th>	
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tr>
			</thead>
			<tbody>
			<?php $__currentLoopData = $records['records']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
				<?php $__currentLoopData = $summaryColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $summaryColumn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php
						$suffix = empty($summaryColumn->options['suffix']) ? '' : (' ' . $summaryColumn->options['suffix']);						
						$cardPageUrl = (in_array($summaryColumn->name, $cardPageUrlColumns, true)) &&  (!empty($cardPageUrls[$index])) ? $cardPageUrls[$index] : '';
						$manyToOneUrl = !empty($manyToOneUrls[$index][$summaryColumn->name]) ? $manyToOneUrls[$index][$summaryColumn->name] : '';
						$oneToManyUrl = !empty($oneToManyUrls[$index][$summaryColumn->name]) ? $oneToManyUrls[$index][$summaryColumn->name] : '';
						$value = $record[$summaryColumn->name];
					?>
					<?php if(!$summaryColumn->isHidden('list')): ?>
						<td>
						<?php if($summaryColumn->type === 'text'): ?>
							<div>
								<?php if($cardPageUrl != ''): ?>
									<a href="<?php echo $cardPageUrl; ?>" class="btn btn-primary"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php elseif($manyToOneUrl != ''): ?>
									<a href="<?php echo $manyToOneUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a> 
								<?php elseif($oneToManyUrl != ''): ?>
									<a href="<?php echo $oneToManyUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php else: ?>
									<?php echo e($value); ?> <?php echo e($suffix); ?>

								<?php endif; ?>
							</div>
						<?php endif; ?>		
						<?php if($summaryColumn->type === 'textlong'): ?>
							<div>
								<?php if($cardPageUrl != ''): ?>
									<a href="<?php echo $cardPageUrl; ?>" class="btn btn-primary"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php elseif($manyToOneUrl != ''): ?>
									<a href="<?php echo $manyToOneUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a> 
								<?php elseif($oneToManyUrl != ''): ?>
									<a href="<?php echo $oneToManyUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>	
								<?php else: ?>
									<?php echo e($value); ?> <?php echo e($suffix); ?>

								<?php endif; ?>
							</div>
						<?php endif; ?>	
						<?php if($summaryColumn->type === 'email'): ?>
							<div>
								<?php if($cardPageUrl != ''): ?>
									<a href="<?php echo $cardPageUrl; ?>" class="btn btn-primary"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php elseif($manyToOneUrl != ''): ?>
									<a href="<?php echo $manyToOneUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a> 
								<?php elseif($oneToManyUrl != ''): ?>
									<a href="<?php echo $oneToManyUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php else: ?>
									<?php echo e($value); ?> <?php echo e($suffix); ?>

								<?php endif; ?>
							</div>
						<?php endif; ?>
						<?php if($summaryColumn->type === 'integer'): ?>
							<div>
								<?php if($cardPageUrl != ''): ?>
									<a href="<?php echo $cardPageUrl; ?>" class="btn btn-primary"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php elseif($manyToOneUrl != ''): ?>
									<a href="<?php echo $manyToOneUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a> 
								<?php elseif($oneToManyUrl != ''): ?>
									<a href="<?php echo $oneToManyUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a> 
								<?php else: ?>
									<?php echo e($value); ?> <?php echo e($suffix); ?>

								<?php endif; ?>
							</div>
						<?php endif; ?>
						<?php if($summaryColumn->type === 'decimal'): ?>
							<div>
								<?php if($cardPageUrl != ''): ?>
									<a href="<?php echo $cardPageUrl; ?>" class="btn btn-primary"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php elseif($manyToOneUrl != ''): ?>
									<a href="<?php echo $manyToOneUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a> 
								<?php elseif($oneToManyUrl != ''): ?>
									<a href="<?php echo $oneToManyUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php else: ?>
									<?php echo e($value); ?> <?php echo e($suffix); ?>

								<?php endif; ?>
							</div>
						<?php endif; ?>
						<?php if($summaryColumn->type === 'enum'): ?>
							<div>
								<?php if($cardPageUrl != ''): ?>
									<a href="<?php echo $cardPageUrl; ?>" class="btn btn-primary"> <?php echo e($summaryColumn->options['enum'][$value]); ?> <?php echo e($suffix); ?> </a>
								<?php elseif($manyToOneUrl != ''): ?>
									<a href="<?php echo $manyToOneUrl; ?>" class="btn btn-default"> <?php echo e($summaryColumn->options['enum'][$value]); ?> <?php echo e($suffix); ?> </a> 
								<?php elseif($oneToManyUrl != ''): ?>
									<a href="<?php echo $oneToManyUrl; ?>" class="btn btn-default"> <?php echo e($summaryColumn->options['enum'][$value]); ?> <?php echo e($suffix); ?> </a>
								<?php else: ?>
									<?php echo e($summaryColumn->options['enum'][$value]); ?> <?php echo e($suffix); ?>

								<?php endif; ?>
							</div>
						<?php endif; ?>	
						<?php if($summaryColumn->type === 'datetime'): ?>
							<div>
								<?php if($cardPageUrl != ''): ?>
									<a href="<?php echo $cardPageUrl; ?>" class="btn btn-primary"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php elseif($manyToOneUrl != ''): ?>
									<a href="<?php echo $manyToOneUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a> 
								<?php elseif($oneToManyUrl != ''): ?>
									<a href="<?php echo $oneToManyUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php else: ?>
									<?php echo e($value); ?> <?php echo e($suffix); ?>

								<?php endif; ?>
							</div>
						<?php endif; ?>				
						<?php if($summaryColumn->type === 'date'): ?>
							<div>
								<?php if($cardPageUrl != ''): ?>
									<a href="<?php echo $cardPageUrl; ?>" class="btn btn-primary"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php elseif($manyToOneUrl != ''): ?>
									<a href="<?php echo $manyToOneUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a> 
								<?php elseif($oneToManyUrl != ''): ?>
									<a href="<?php echo $oneToManyUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php else: ?>
									<?php echo e($value); ?> <?php echo e($suffix); ?>

								<?php endif; ?>
							</div>
						<?php endif; ?>
						<?php if($summaryColumn->type === 'time'): ?>
							<div>
								<?php if($cardPageUrl != ''): ?>
									<a href="<?php echo $cardPageUrl; ?>" class="btn btn-primary"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php elseif($manyToOneUrl != ''): ?>
									<a href="<?php echo $manyToOneUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php elseif($oneToManyUrl != ''): ?>
									<a href="<?php echo $oneToManyUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php else: ?>
									<?php echo e($value); ?> <?php echo e($suffix); ?>

								<?php endif; ?>
							</div>
						<?php endif; ?>									
						<?php if($summaryColumn->type === 'boolean'): ?>
							<div>
								
								<?php if($cardPageUrl != ''): ?>
									<a href="<?php echo $cardPageUrl; ?>" class="btn btn-primary"> <?php echo e($value); ?></a>
								<?php elseif($manyToOneUrl != ''): ?>
									<a href="<?php echo $manyToOneUrl; ?>" class="btn btn-default"> <?php echo e($value); ?></a> 
								<?php elseif($oneToManyUrl != ''): ?>
									<a href="<?php echo $oneToManyUrl; ?>" class="btn btn-default"> <?php echo e($value); ?> <?php echo e($suffix); ?> </a>
								<?php else: ?>
									<?php if($value === $texts['yes']): ?>
										<code class="bg-success text-success"><?php echo e($value); ?></code>
									<?php else: ?>
										<code class="bg-danger text-danger"><?php echo e($value); ?></code>
									<?php endif; ?>
								<?php endif; ?>
							</div>
						<?php endif; ?>				
						<?php if($summaryColumn->type === 'image'): ?>
							<div>
								<span><code class="bg-warning text-primary"><?php echo e($value); ?></code></span>
							</div>
						<?php endif; ?>
						<?php if($summaryColumn->type === 'blob'): ?>
							<div>
								<span><code class="bg-warning text-primary"><?php echo e($value); ?></code></span>
							</div>
						<?php endif; ?>
						</td>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<!-- Line Actions -->
				<?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actionName => $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($action['on-list']): ?>
						<?php 
							$faIconClass = !empty($action['fa-icon']) ? 'fa fa-'.$action['fa-icon'] : '';	
							$btnClass = !empty($action['btn-class']) ? 'btn btn-'.$action['btn-class'] : 'btn btn-default';
							$btnClass .= $action['disabled'] ? ' disabled' : '';							
						?>
						<td>
							<form action="<?php echo e(action('\Alddesign\Crudkit\Controllers\AdminPanelController@action')); ?>" method="post" class="crudkit-line-action">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
								<input type="hidden" name="page-id" value="<?php echo e($pageId); ?>" />
								<input type="hidden" name="action-name" value="<?php echo e($actionName); ?>" />
								<?php $__currentLoopData = $primaryKeyColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $primaryKeyColumnName => $primaryKeyColumn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<input type="hidden" name="pk-<?php echo $loop->index; ?>" value="<?php echo e($record[$primaryKeyColumnName]); ?>" />
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<button type="submit" class="<?php echo e($btnClass); ?> crudkit-line-action-button">
									<?php if($faIconClass != ''): ?><i class="<?php echo e($faIconClass); ?>"></i> &nbsp;<?php endif; ?>
									<?php echo e($action['label']); ?>

								</button>
							</form>
						</td>	
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		<!-- Pagination -->
		<?php if(count($records['records']) < $records['total']): ?>
			<?php
				$showFirst = ($pageNumber > 1);
				$showLast = ($pageNumber * $recordsPerPage) < $records['total'];
			?>
			<ul class="pagination">
				<!-- First / Previous -->
				<?php if($showFirst): ?>
					<li><a href="<?php echo e($paginationUrls['first']); ?>"><?php echo e($texts['first']); ?></a></li>
					<li><a href="<?php echo e($paginationUrls['previous']); ?>"><?php echo e($texts['prev']); ?></a></li>
				<?php else: ?> 
					<li class="disabled"><span><?php echo e($texts['first']); ?></span></li>
					<li class="disabled"><span class="disabled"><?php echo e($texts['prev']); ?></span></li>
				<?php endif; ?>
				
				<!-- Pages -->
				<?php if(isset($paginationUrls['predot'])): ?> <li class="disabled"><span>...</span></li> <?php endif; ?>
				<?php $__currentLoopData = $paginationUrls['pages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li class="<?php if($index == $pageNumber): ?><?php echo e('active'); ?> <?php endif; ?>"><a href="<?php echo e($url); ?>"><?php echo e($index); ?></a></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php if(isset($paginationUrls['afterdot'])): ?> <li class="disabled"><span>...</span></li> <?php endif; ?>
				<!-- Last / Next -->
				<?php if($showLast): ?>
					<li><a href="<?php echo e($paginationUrls['next']); ?>"><?php echo e($texts['next']); ?></a></li>
					<li><a href="<?php echo e($paginationUrls['last']); ?>"><?php echo e($texts['last']); ?></a></li>
				<?php else: ?>
					<li class="disabled"><span><?php echo e($texts['next']); ?></span></li>
					<li class="disabled"><span><?php echo e($texts['last']); ?></span></li>
				<?php endif; ?>
			</ul>
		<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('crudkit::core-admin-panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>