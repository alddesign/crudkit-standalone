<?php $__env->startSection('core-admin-panel'); ?>
<section class="content-header">
	<div class="row">
		<div class="col-md-4">
			<h2 id="crudkit-page-title">
				<?php if(isset($listPageUrl) && $listPageUrl !== ''): ?>
				<a href="<?php echo e($listPageUrl); ?>" class="btn btn-primary btn-sm" style="margin-top: -5px;"><i class="fa fa-chevron-left"></i></a>
				<?php endif; ?>
				<?php echo e($pageName); ?>

				<!-- QR Code -->
				<?php if(isset($qrCode) && $qrCode !== ''): ?>
				<span id="crudkit-qrcode-tooltip-container">
					<a id="crudkit-qrcode-tooltip" href="#" title="<?php echo e($qrCode); ?>">
						<span class="fa fa-qrcode"></span>
					</a>
				</span>
				<?php endif; ?>
			</h2>
		</div>
		<div class="col-md-8">
			<div class="pull-right">
				<?php echo $__env->yieldContent('action-buttons'); ?>
			</div>
		</div>
	</div>
	<?php if($pageTitleText !== ''): ?>
	<div class="row">
		<div class="col-md-6">
			<h3 style="margin-top: 0px">
				<small><?php echo $pageTitleText; ?></small>
			</h3>
		</div>
		<div class="col-md-6">
		</div>
	</div>
	<?php endif; ?>
</section>
<section class="content">
	<div class="box box-primary" style='padding-top:15px'>
		<div class="box-body" >
			<?php echo $__env->yieldContent('page-content'); ?>
		</div>
	</div> 
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('crudkit::layouts.core-body', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>